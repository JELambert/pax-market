# Fearon & Laitin (2003) — Praxis PAX

**"Ethnicity, Insurgency, and Civil War"**

Foundational paper challenging ethnic grievance explanations of civil war.
Finds that insurgency-opportunity factors (poverty, rough terrain, weak states,
large populations) are stronger predictors of civil war onset than ethnic or
religious diversity.

## Contents

- **1 domain:** Intra-State Conflict
- **10 constructs:** civil_war_onset, per_capita_income, mountainous_terrain,
  population_size, political_instability, anocracy, oil_exporter, new_state,
  noncontiguous_territory, religious_fractionalization
- **11 findings:** Empirical results from logistic regression on country-year panel (N=6,327)
- **10 aliases:** Covering key synonyms and operationalizations

## Source

Fearon, James D.; Laitin, David D. (2003). "Ethnicity, Insurgency, and Civil War."
*American Political Science Review* 97(1): 75-90. DOI: 10.1017/S0003055403000534
